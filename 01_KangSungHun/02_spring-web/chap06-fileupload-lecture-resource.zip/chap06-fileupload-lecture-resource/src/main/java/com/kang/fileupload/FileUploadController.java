package com.kang.fileupload;


import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

@Controller
public class FileUploadController {

    @Value("${spring.servlet.multpart.location}")
    private String filePath;

    // MultipartFile :
    // - 요청 형식이 multipart/form-data일 때
    //   MultipartResolver가 구분하여 처리한 데이터 중 File을 지칭하는 객체

    @PostMapping("/single-file")
    public String singleFileUpload(
            @RequestParam("singleFileDescription") String singleFileDescription,
            @RequestParam MultipartFile singleFile

            ) {

        System.out.println("singleFileDescription = " + singleFileDescription);
        System.out.println("singleFile = " + singleFile);
        System.out.println(singleFile.getOriginalFilename()); // 제출 파일명
        System.out.println(singleFile.getSize()); // 파일 크기(byte)

        /* 서버 컴퓨터에 제출된 파일을 저장 */

        // 1. 저장할 폴더를 지정

        return "result";
    }
}
