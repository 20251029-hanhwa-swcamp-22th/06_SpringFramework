package com.kang.fileupload;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Chap06FileuploadLectureResourceApplication {

    public static void main(String[] args) {
        SpringApplication.run(Chap06FileuploadLectureResourceApplication.class, args);
    }

}
