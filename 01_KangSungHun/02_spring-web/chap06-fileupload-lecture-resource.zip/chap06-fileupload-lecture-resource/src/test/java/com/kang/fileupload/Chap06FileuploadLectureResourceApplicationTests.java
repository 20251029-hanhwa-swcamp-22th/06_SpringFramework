package com.kang.fileupload;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Chap06FileuploadLectureResourceApplicationTests {

    @Test
    void contextLoads() {
    }

}
