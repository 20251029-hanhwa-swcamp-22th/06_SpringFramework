package com.kang.interceptor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Chap05InterceptorLectureSourceApplication {

    public static void main(String[] args) {
        SpringApplication.run(Chap05InterceptorLectureSourceApplication.class, args);
    }

}
